//
//  SignInView.swift
//  lab10
//
//  Created by Алишер Алсейт on 24.11.2021.
//

import SwiftUI
import LocalAuthentication




struct SignInView: View {
    @EnvironmentObject var model: ContentModel
    @AppStorage("stored_User") var phoneNumber = "77077077777"
    var body: some View {
        
        ZStack {
            
            VStack {
                Rectangle()
                    .foregroundColor(.gray)
                    .cornerRadius(15)
                    .edgesIgnoringSafeArea(.top)
                
                Rectangle()
                    .foregroundColor(.white)
            }
            VStack(spacing: 30) {
                
                Text("Вход")
                
                TextField("Номер", text: $model.phone)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                
                SecureField("Пароль", text: $model.password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Отправить")
                    .onTapGesture {
                        model.login(phone: model.phone, password: model.password) { _ in
                            
                            model.check()
                            
                            model.phone = ""
                            model.password = ""
                        }
                    }
                
                if bio(){
                    
                    Button(action: userAuth, label: {
                        
                        // getting biometrictype...
                        Image(systemName: LAContext().biometryType == .faceID ? "face.smiling" : "hand.point.up.left")
                            .font(.title)
                            .foregroundColor(.black)
                            .padding()
                            .background(Circle().foregroundColor(.green))
                            .clipShape(Circle())
                    })
                }
            }
            .padding()
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .shadow(radius: 10)
                    .padding()
            )
        }
    }
    
    
    func bio()->Bool{
        
        let scanner = LAContext()
        if model.phone == phoneNumber && scanner.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: .none){
            
            return true
        }
        
        return false
    }

    func userAuth(){
        
        let scanner = LAContext()
        scanner.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "To Unlock \(model.phone)") { (status, err) in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            
            
            withAnimation(.easeOut){
                DispatchQueue.main.async {
                    model.loggedIn = true
                }
                
            }
        }
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
            .environmentObject(ContentModel())
    }
}
