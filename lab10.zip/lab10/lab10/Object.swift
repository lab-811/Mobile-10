//
//  Object.swift
//  Lab10Zh
//
//  Created by Islambek on 17.11.2021.
//

import SwiftUI

struct Items:  Identifiable, Decodable {
    

    var id = UUID()
    var title: String
    var latitude: Double
    var longitude: Double
    
}
    
    var mapItems = [
    
    
        Items(title: "7food", latitude: 43.239200, longitude: 76.905821),
        Items(title: "7food", latitude: 43.249829, longitude: 76.888155)
    ]

struct FridgeItem: Decodable, Identifiable {
    
    var id = UUID()
    var image: String
    var address: String
    var count: String
    var name: String
    var secondItem: String
    var price: String
    
}


var fridgeItems = [

    FridgeItem(image: "fridge", address: "N8 мкр. 25", count: "21x", name: "Лимонад 7F 0.5", secondItem: "", price: "4200"),
    FridgeItem(image: "fridge", address: "N8 мкр. 25", count: "0x", name: "Кола 0.5L", secondItem: "Кола 2.0L", price: "0"),
    FridgeItem(image: "fridge", address: "N8 мкр. 25", count: "0x", name: "Кола 0.5L", secondItem: "Кола 2.0L", price: "0"),
    FridgeItem(image: "fridge", address: "N8 мкр. 25", count: "-1x", name:"Кола 0.5L",secondItem:  "Кола 2.0L", price: "-570"),
    FridgeItem(image: "fridge", address: "N8 мкр. 25", count: "0x", name: "Кола 0.5L", secondItem: "Кола 2.0L", price: "-570"),
    FridgeItem(image: "fridge", address: "N8 мкр. 25", count: "0x", name: "Кола 0.5L", secondItem: "Кола 2.0L", price: "-570")
 
 
    
]

