//
//  lab10App.swift
//  lab10
//
//  Created by Islambek on 17.11.2021.
//

import SwiftUI

@main
struct lab10App: App {
    var body: some Scene {
        WindowGroup {
            FirstView()
                .environmentObject(ContentModel())
        }
    }
}
