//
//  FirstView.swift
//  lab10
//
//  Created by Алишер Алсейт on 24.11.2021.
//

import SwiftUI

class ContentModel: ObservableObject {
    
    @Published var loggedIn = false
    @AppStorage("token") var token = ""
    @Published var phone = ""
    @Published var password = ""
    
    func check() {
        DispatchQueue.main.async {
            self.loggedIn = self.token == "" ? false : true
        }
      
        
        
    }
    
    func logout() {
        
        token = ""
        
    }
    
    func login(phone: String, password: String, completion: @escaping (String) -> Void) {
        print("Performin Login")
        
        guard let url = URL(string: "https://7food.kz/api/auth/login")
        else { return }
        
        var loginRequest = URLRequest(url: url)
        loginRequest.httpMethod = "POST"
        
        do {
            // fromSwiftApp@mail.ru pass: 123123
            let params = ["phone": phone, "password": password]
            loginRequest.httpBody = try JSONSerialization.data(withJSONObject: params, options: .init())
            
            loginRequest.setValue("application/json", forHTTPHeaderField: "content-type")
            
            URLSession.shared.dataTask(with: loginRequest) { (data, resp, err) in
                
                if let err = err {
                    print("failed:", err)
                    return
                }
                
               
                
                if let data = data {
                    do {
                        if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary {
                            
                            let responseError = convertedJsonIntoDict["error"] as? String
                            
                            
                            
                            if responseError?.count == nil {
                                
                                DispatchQueue.main.async {
                                    let tokenAcceso = convertedJsonIntoDict["token"] as? String
                                    self.token = tokenAcceso!
                                    completion("success")
                                    print("my token = \(self.token)")
                                    
                                }
                            } else {
                                print("error")
                            }
                        }
                    }
                    catch let error as NSError {
                        
                        print(error.localizedDescription)
                    }
                }
                
                
                
            }.resume()
            
        }
        catch {
            print("Failed to serilaize data:", error)
        }
        
    }
}

struct FirstView: View {
    @EnvironmentObject var model: ContentModel
    var body: some View {
        if !model.loggedIn {
            SignInView()
                .onAppear {
                    
                    
                    model.check()
                }
        } else {
            
                ContentView()
                    
                
            
               
        }
    }
}

struct FirstView_Previews: PreviewProvider {
    static var previews: some View {
        FirstView()
            .environmentObject(ContentModel())
    }
}
